VANTA.RINGS({
  el: "#intro",
  backgroundColor: 0x20202,
  color: 0xcdba2f
})
